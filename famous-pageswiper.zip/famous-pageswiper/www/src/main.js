/*** Main Application Entry ***/

define(function(require) {
    var Engine  = require('famous/core/Engine');
    var Surface = require('famous/core/Surface');

    var PageSwiper = require('views/PageSwiper');

	var _width = 320;
    // Figure out height so I know if I'm dealing with iphone 4 or 5
    var _height = window.innerHeight;
    if (_height > 568) {
        _height = 569;
    }
    if (_height < 480) {
        _height = 480;
    }

    var init = function() {
        var engine = Engine.createContext();
        
        var pageSwiper = new PageSwiper();

        engine.add(pageSwiper);
    };

    // Call this at the end to ensure app functions have been initialized
    init();
});